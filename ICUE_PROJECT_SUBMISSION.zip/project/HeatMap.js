// This example requires the Visualization library. Include the libraries=visualization
    // parameter when you first load the API. For example:
    // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=visualization">
    let map, heatmap, age;
    const results = [];
    const coordinates = [];
    const ageGroups = [];
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    async function fetchData() {
        const response = await fetch('https://opendata.arcgis.com/datasets/4dabb4afab874804ba121536efaaacb4_0.geojson')
        const data = await response.json();
        return data;
    }

    function initMap() {
        map = new google.maps.Map(document.getElementById("map"), {
            zoom: 3,
            center: { lat: 56.1304, lng: -106.3468 },
            mapTypeId: "roadmap",
        });
        fetchData().then((data) => {
                results.push(data.features.map((positiveCase) => positiveCase.properties));
                coordinates.push(results[0].map(({latitude, longitude}) => Object.assign({}, {latitude}, {longitude})));
                ageGroups.push(results[0].map(({age_group}) => Object.assign({}, {age_group})));
                console.log(ageGroups[0][0].age_group)
                heatmap = new google.maps.visualization.HeatmapLayer({
                    data: getPoints(),
                    map: map,
                });
            }
        )
    }

    function drawChart() {
      var age80 = "80+", age70 = "70-79", age60 = "60-69", age50 = "50-59", age40 = "40-49", age30 = "30-39", age20 = "20-29", ageless="<20"
      var age80count = 0, age70count = 0, age60count = 0, age50count = 0, age40count = 0, age30count = 0, age20count = 0, agelesscount = 0;
      for(i = 0; i < ageGroups[0].length; i++){
            if(ageGroups[0][i].age_group === age80)
                ++age80count;
            if(ageGroups[0][i].age_group === age70)
                ++age70count;
            if(ageGroups[0][i].age_group === age60)
                ++age60count;
            if(ageGroups[0][i].age_group === age50)
                ++age50count;
            if(ageGroups[0][i].age_group === age40)
                ++age40count;
            if(ageGroups[0][i].age_group === age30)
                ++age30count;
            if(ageGroups[0][i].age_group === age20)
                ++age20count;
            if(ageGroups[0][i].age_group === ageless)
                ++agelesscount;
      };
      var data = google.visualization.arrayToDataTable([
        ['Age', 'Cases'],
        ['80+',age80count],
        ['70-79',age70count],
        ['60-69',age60count],
        ['50-59',age50count],
        ['40-49',age40count],
        ['30-39',age30count],
        ['20-29',age20count],
        ['<20',agelesscount],
      ]);

      var options = {backgroundColor: 'transparent',

        'title': 'Cases per Age-Group in Canada',
        
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));

      chart.draw(data, options);
    }
   
    

    function toggleHeatmap() {
        heatmap.setMap(heatmap.getMap() ? null : map);
    }

    function changeGradient() {
        const gradient = [
            "rgba(0, 255, 255, 0)",
            "rgba(0, 255, 255, 1)",
            "rgba(0, 191, 255, 1)",
            "rgba(0, 127, 255, 1)",
            "rgba(0, 63, 255, 1)",
            "rgba(0, 0, 255, 1)",
            "rgba(0, 0, 223, 1)",
            "rgba(0, 0, 191, 1)",
            "rgba(0, 0, 159, 1)",
            "rgba(0, 0, 127, 1)",
            "rgba(63, 0, 91, 1)",
            "rgba(127, 0, 63, 1)",
            "rgba(191, 0, 31, 1)",
            "rgba(255, 0, 0, 1)"
        ];
        heatmap.set("gradient", heatmap.get("gradient") ? null : gradient);
    }

    function changeRadius() {
        heatmap.set("radius", heatmap.get("radius") ? null : 40);
    }

    function changeOpacity() {
        heatmap.set("opacity", heatmap.get("opacity") ? null : 0.2);
    }

    // Heatmap data: 500 Points
    function getPoints() {
        const points = coordinates[0].map(({latitude, longitude}) => {
            return new google.maps.LatLng(latitude, longitude);
        })
        return [
            new google.maps.LatLng(37.782551, -122.445368),
            {location: new google.maps.LatLng(37.782, 122.443), weight: 2},
            ...points
        ];
    }